*Compilation and Execution :-

    gcc maze_game.c -o maze_game -std=c99 && ./maze_game > output.txt


* Poles and stairs are working , it depend on the input
